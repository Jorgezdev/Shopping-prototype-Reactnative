### Contributing to Enatega Restaurant Solution

Welcome to Enatega Restaurant Solution! We're excited you're here and want to contribute.

### Getting Started

If you would like to become an active contributor please read this document in its entireity. This will help you get started and answer any questions you may have.

### How can I help?

There are many ways you can help contribute to Enatega Restaurant Solution. Here are a few ideas:

- Developers can make contribution to the code
- Designers can make contribution to the design
- Writers can make contribution to the documentation
- Testers can make contribution to the testing
- Translators can make contribution to the translation
