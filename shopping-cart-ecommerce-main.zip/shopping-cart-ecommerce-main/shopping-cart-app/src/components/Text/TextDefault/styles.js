import { StyleSheet } from 'react-native'

const color = textColor =>
  StyleSheet.create({
    color: {
      color: textColor
    }
  })

export default color
