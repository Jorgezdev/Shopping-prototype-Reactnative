module.exports = 'prettier-config-standard'
